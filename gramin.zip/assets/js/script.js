var app = angular.module("gramin", ["ngRoute"]);

